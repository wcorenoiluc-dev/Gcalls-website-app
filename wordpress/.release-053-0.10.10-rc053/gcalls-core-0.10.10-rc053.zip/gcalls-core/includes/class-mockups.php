<?php
/**
 * Product mockups — the React home page visuals, ported.
 *
 * WHY THESE ARE MARKUP AND NOT SCREENSHOTS
 * Seven components on the React home page are interactive: they have tabs you
 * switch, lists you select from, a playback progress bar and a call timer. A
 * screenshot of one is a picture of a single frame, and a reviewer clicking it
 * learns that the demo is a picture. So they are rebuilt as semantic HTML with
 * real buttons — which also means they are keyboard operable, which a screenshot
 * never is.
 *
 * THE THREE EXCEPTIONS, AND WHY THEY ARE IMAGES
 * `*_showcase` at the foot of this file are images, and only ever heroes. The
 * argument above is about a panel a reader can reach and click; a hero is the
 * first screen, judged at a glance and usually not touched. What it has to do
 * is look like software, and a full application frame — sidebar, list, working
 * pane — is what does that. The markup panels are deliberately small and
 * single-purpose; stretched across a hero, one shows four rows and a lot of
 * white. So each of CX, Voicebot and QC leads with a drawn frame and keeps its
 * interactive panel further down the same page, where clicking it is possible
 * and therefore worth having. The images are generated, not photographed —
 * see wordpress/scripts/build-demo-imagery.mjs for the source and the rules.
 *
 * WHY THE DATA IS FAKE AND SAYS SO
 * The React source uses plausible Vietnamese personal names and company names.
 * Carrying those onto a public demo would put invented people beside a real
 * brand. Everything here is Khách hàng A/B/C, Công ty Demo, phone numbers masked
 * to the last two digits and example.com addresses, and every visual carries a
 * caption saying it is demo data. The numbers are shapes, not results: none of
 * them is presented as an achievement.
 *
 * WHAT THE MARKUP GUARANTEES
 * Every mockup reserves its own height through aspect-ratio or a min-height, so
 * nothing below it moves when the JavaScript wakes up. Without JavaScript each
 * one renders its first state and stays there — a still panel, not an empty box.
 *
 * @package Gcalls\Core
 */

declare( strict_types = 1 );

namespace Gcalls\Core;

defined( 'ABSPATH' ) || exit;

/**
 * `[gcalls_mockup id="…"]`
 */
final class Mockups {

	/** Registers the shortcode. */
	public static function init(): void {
		add_shortcode( 'gcalls_mockup', array( self::class, 'render' ) );
	}

	/** Demo contacts. Deliberately anonymous — see the file header. */
	private const CONTACTS = array(
		array( 'name' => 'Khách hàng A', 'org' => 'Công ty Demo 1', 'phone' => '090 *** **12', 'tag' => 'Khách hàng mới' ),
		array( 'name' => 'Khách hàng B', 'org' => 'Công ty Demo 2', 'phone' => '091 *** **34', 'tag' => 'VIP' ),
		array( 'name' => 'Khách hàng C', 'org' => 'Công ty Demo 3', 'phone' => '098 *** **56', 'tag' => '' ),
		array( 'name' => 'Khách hàng D', 'org' => 'Công ty Demo 4', 'phone' => '097 *** **78', 'tag' => '' ),
	);

	/** Demo agents. */
	private const AGENTS = array(
		array( 'name' => 'Nhân viên 1', 'state' => 'available', 'label' => 'Sẵn sàng' ),
		array( 'name' => 'Nhân viên 2', 'state' => 'in-call', 'label' => 'Đang gọi' ),
		array( 'name' => 'Nhân viên 3', 'state' => 'available', 'label' => 'Sẵn sàng' ),
		array( 'name' => 'Nhân viên 4', 'state' => 'away', 'label' => 'Vắng mặt' ),
		array( 'name' => 'Nhân viên 5', 'state' => 'offline', 'label' => 'Ngoại tuyến' ),
	);

	/**
	 * Drawings that exist in this file but must never render.
	 *
	 * Kept as a list of METHOD names rather than of ids, so that adding a new
	 * id that happens to resolve to one of them cannot quietly re-open it.
	 */
	private const REFUSED_METHODS = array( 'mock_analytics', 'mock_plus_gallery' );

	/**
	 * The fixed label every illustrative surface carries.
	 *
	 * One source of truth with the raster registry: media-frames.json already
	 * has to state it for the images, and a drawn panel making the same claim
	 * must not be able to drift to a different wording.
	 */
	private static function illustrative_label(): string {
		$reg = self::frames();

		$label = (string) ( $reg['label'] ?? '' );

		return '' !== $label ? $label : 'Giao diện minh hoạ · Dữ liệu mẫu';
	}

	/**
	 * The caption every mockup carries.
	 *
	 * GCALLS-041: the default is now the same fixed wording the raster registry
	 * uses, so a drawn mockup and an approved image make the identical
	 * statement. Two nearly-identical captions ("dữ liệu demo" here, "Dữ liệu
	 * mẫu" there) read as two different promises when they are meant to be one.
	 */
	private static function caption( string $text = '' ): string {
		$text = '' !== $text ? $text : self::illustrative_label();

		return '<p class="gcalls-mock__caption">' . esc_html( $text ) . '</p>';
	}

	/** A window chrome header, shared by every mockup. */
	private static function chrome( string $title ): string {
		return '<div class="gcalls-mock__bar"><span class="gcalls-mock__dot"></span><span class="gcalls-mock__dot"></span>'
			. '<span class="gcalls-mock__dot"></span><span class="gcalls-mock__title">' . esc_html( $title ) . '</span></div>';
	}

	/**
	 * Renders one mockup.
	 *
	 * @param array<string, string>|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function render( $atts = array() ): string {
		$atts = shortcode_atts( array( 'id' => '' ), (array) $atts, 'gcalls_mockup' );
		$id   = sanitize_key( str_replace( '-', '_', (string) $atts['id'] ) );

		/*
		 * REFUSED. `mock_analytics` draws a dashboard whose KPI tiles (114,
		 * 73%, 3:25) and bar values are invented, presented as a product's
		 * measured performance. GCALLS-036B classified it REFUSED_DATA and
		 * GCALLS-036C removes it from the rendered surface. The method body is
		 * left in place rather than deleted so the decision is reviewable and
		 * reversible by the owner, but nothing can reach it.
		 *
		 * Labelling was considered and rejected: a caption under a fabricated
		 * performance chart still leaves the chart as the thing the reader
		 * remembers, and there is no measurement anywhere in this repository it
		 * could be replaced with.
		 *
		 * BUT THE ID IS REMAPPED, NOT DROPPED. Returning '' for `analytics`
		 * looked free while only the four product pages were being measured,
		 * because none of them ask for it. The home page does: root section 11
		 * of data/homepage-elementor.json is a heading, a paragraph, and this
		 * shortcode as the section's only visual. An empty string there leaves
		 * a heading over an empty column — the "heading orphan over an empty
		 * grid track" that fails a route in acceptance. So `analytics` resolves
		 * to `reporting`, a neutral panel that names the metrics the product
		 * reports and states none of them.
		 */
		$id = ( 'analytics' === $id ) ? 'reporting' : $id;

		$method = 'mock_' . $id;

		/*
		 * Belt and braces. The refused drawings stay in the file so the
		 * decision stays reviewable, but no id may reach one — including
		 * 'analytics' itself, which the line above has already sent elsewhere.
		 */
		if ( in_array( $method, self::REFUSED_METHODS, true ) ) {
			return '';
		}

		if ( ! method_exists( self::class, $method ) ) {
			return '';
		}

		wp_enqueue_style( 'gcalls-mockups', GCALLS_CORE_URL . 'assets/css/mockups.css', array(), VERSION );
		wp_enqueue_script( 'gcalls-mockups', GCALLS_CORE_URL . 'assets/js/mockups.js', array(), VERSION, true );

		return '<div class="gcalls-mock" data-gcalls-mock="' . esc_attr( $id ) . '">' . self::$method() . '</div>';
	}

	/* -------------------------------------------------------------- 1. hero */

	/**
	 * HeroSection — the webphone dashboard.
	 *
	 * React drives a playback progress bar on an interval and a KPI strip. The
	 * KPI values are shapes, not measurements, and the caption says so.
	 */
	private static function mock_hero(): string {
		/*
		 * Four metric NAMES, because the reference's strip is a four-column
		 * grid and a three-column port reads as a different component.
		 *
		 * GCALLS-041 removed the values. The earlier reasoning here was that
		 * "73%" under an illustrative caption reads as a shape while "+12%"
		 * reads as a claim — so the deltas went and the values stayed. Rendering
		 * the home page for the first time showed how that actually lands: the
		 * strip sits in the first screenful, four numbers wide, and reads as
		 * this product's results. It is the same claim GCALLS-039 refused on
		 * mock_analytics, in a more prominent place. Same layout, same four
		 * columns, no figures.
		 */
		$kpis = array( 'Cuộc gọi hôm nay', 'Tỷ lệ nghe máy', 'Thời gian TB', 'Đã chốt deal' );

		/* The dashboard, which is the stage's main card. */
		$main  = self::chrome( 'Gcalls Webphone — Dashboard' );
		$main .= '<div class="gcalls-mock__strip gcalls-mock__strip--in"><span class="gcalls-mock__pulse" aria-hidden="true"></span>';
		$main .= '<span><strong>Cuộc gọi đến</strong> · ' . esc_html( self::CONTACTS[0]['name'] ) . '</span>';
		$main .= '<span class="gcalls-mock__muted">' . esc_html( self::CONTACTS[0]['phone'] ) . '</span>';
		$main .= '<span class="gcalls-mock__badge">Đang đổ chuông</span></div>';

		$main .= '<div class="gcalls-mock__kpis">';
		foreach ( $kpis as $kpi ) {
			$main .= '<div class="gcalls-mock__kpi"><span>' . esc_html( $kpi ) . '</span>'
				. '<strong aria-label="' . esc_attr__( 'chưa có số liệu', 'gcalls-core' ) . '">' . self::FIGURE . '</strong></div>';
		}
		$main .= '</div>';

		/* A short call list, so the frame reads as a working screen. */
		$rows = array(
			array( 'A', 'Khách hàng A', 'Gọi đi · 3:42', '09:14', 'out' ),
			array( 'B', 'Khách hàng B', 'Gọi đến · 7:18', '09:31', 'in' ),
			array( 'C', 'Khách hàng C', 'Nhỡ', '09:52', 'missed' ),
		);

		$main .= '<ul class="gcalls-mock__list gcalls-mock__list--calls">';
		foreach ( $rows as $row ) {
			$main .= '<li><span class="gcalls-mock__avatar">' . esc_html( $row[0] ) . '</span>';
			$main .= '<span class="gcalls-mock__who"><strong>' . esc_html( $row[1] ) . '</strong>';
			$main .= '<small>' . esc_html( $row[2] ) . '</small></span>';
			$main .= '<span class="gcalls-mock__kind gcalls-mock__kind--' . esc_attr( $row[4] ) . '">' . esc_html( $row[3] ) . '</span></li>';
		}
		$main .= '</ul>';

		/*
		 * The recording card. This is the one float the reference keeps below
		 * `lg`; the other three are desktop-only because at 390px they overlap
		 * each other and clip their own contents.
		 */
		$wave = '';
		for ( $i = 0; $i < 34; $i++ ) {
			// Deterministic, not random: the reference had to stop re-rolling
			// these on every playback tick because the waveform visibly boiled.
			$h     = (int) max( 4, 10 + sin( $i * 0.7 ) * 6 + sin( $i * 1.3 ) * 8 );
			$wave .= '<span style="height:' . esc_attr( (string) $h ) . 'px"></span>';
		}

		$timeline  = '<div class="gcalls-mock__cardhead"><strong>' . esc_html__( 'Bản ghi cuộc gọi', 'gcalls-core' ) . '</strong>';
		$timeline .= '<span class="gcalls-mock__badge">Đã nghe</span></div>';
		$timeline .= '<div class="gcalls-mock__wave" aria-hidden="true">' . $wave . '</div>';
		$timeline .= '<div class="gcalls-mock__player"><button type="button" class="gcalls-mock__play" data-mock-play aria-pressed="false">';
		$timeline .= '<span class="screen-reader-text">Phát bản ghi minh họa</span><span aria-hidden="true">▶</span></button>';
		$timeline .= '<div class="gcalls-mock__track"><div class="gcalls-mock__fill" data-mock-progress style="width:38%"></div></div>';
		$timeline .= '<span class="gcalls-mock__time" data-mock-elapsed>0:38</span></div>';

		/* Weekly shape — bars only, no axis values. */
		$bars = '';
		foreach ( array( 46, 62, 78, 54, 88, 40, 28 ) as $pct ) {
			$bars .= '<span style="height:' . esc_attr( (string) $pct ) . '%"></span>';
		}

		$analytics  = '<div class="gcalls-mock__cardhead"><strong>' . esc_html__( 'Hiệu suất tuần', 'gcalls-core' ) . '</strong></div>';
		$analytics .= '<div class="gcalls-stage__bars" aria-hidden="true">' . $bars . '</div>';

		/* The identification moment, in miniature. */
		$popup  = '<div class="gcalls-mock__cardhead"><strong>' . esc_html__( 'Cuộc gọi đến', 'gcalls-core' ) . '</strong>';
		$popup .= '<span class="gcalls-mock__pulse" aria-hidden="true"></span></div>';
		$popup .= '<div class="gcalls-mock__who"><strong>' . esc_html( self::CONTACTS[0]['name'] ) . '</strong>';
		$popup .= '<small>' . esc_html( self::CONTACTS[0]['org'] ) . ' · ' . esc_html( self::CONTACTS[0]['phone'] ) . '</small></div>';

		/* Dialpad. */
		$keys = '';
		foreach ( array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#' ) as $key ) {
			$keys .= '<span>' . esc_html( $key ) . '</span>';
		}

		$dialpad  = '<div class="gcalls-mock__dialnum">090 *** **12</div>';
		$dialpad .= '<div class="gcalls-mock__keys" aria-hidden="true">' . $keys . '</div>';

		$float = static function ( string $name, string $body, bool $lg_only = false ): string {
			return '<div class="gcalls-stage__float gcalls-stage__float--' . esc_attr( $name )
				. ( $lg_only ? ' gcalls-stage__float--lg' : '' ) . '">' . $body . '</div>';
		};

		$out  = '<div class="gcalls-stage">';
		$out .= '<div class="gcalls-stage__main">' . $main . '</div>';
		$out .= $float( 'timeline', $timeline );
		$out .= $float( 'analytics', $analytics, true );
		$out .= $float( 'popup', $popup, true );
		$out .= $float( 'dialpad', $dialpad, true );
		$out .= '</div>';

		return $out . self::caption();
	}

	/* ------------------------------------------------ raster frame registry */

	/** @var array<string, mixed>|null Cached media-frames.json. */
	private static $frames_registry = null;

	/**
	 * The one allowlist every raster image must pass through.
	 *
	 * GCALLS-038 found two hardcoded frame lists in this file that never
	 * consulted media policy, so six images carrying an unapproved domain,
	 * fabricated identities and invented KPIs shipped on the Gcalls Plus page.
	 * Both lists now resolve through here, and anything not explicitly PASS
	 * renders nothing.
	 *
	 * @return array<string, mixed>
	 */
	private static function frames(): array {
		if ( null === self::$frames_registry ) {
			$file = GCALLS_CORE_DIR . 'data/media-frames.json';
			$raw  = is_readable( $file ) ? (string) file_get_contents( $file ) : '';
			$data = json_decode( $raw, true );

			self::$frames_registry = is_array( $data ) ? $data : array( 'frames' => array() );
		}

		return self::$frames_registry;
	}

	/**
	 * Renders one registered frame, or nothing.
	 *
	 * FAIL CLOSED. An unknown id, a missing id, any verdict other than PASS, or
	 * a missing file on disk all return the empty string. There is deliberately
	 * no parameter for a URL or a filename: a caller cannot name an image this
	 * registry has not approved, which is the hole GCALLS-038 reported.
	 *
	 * @param string $id  Registry key.
	 * @param bool   $eager Whether this is the page's lead image.
	 */
	private static function frame( string $id, bool $eager = true ): string {
		$reg = self::frames();
		$f   = $reg['frames'][ $id ] ?? null;

		if ( ! is_array( $f ) || 'PASS' !== ( $f['verdict'] ?? '' ) ) {
			return '';
		}

		$file = (string) ( $f['file'] ?? '' );

		if ( '' === $file || ! is_readable( GCALLS_CORE_DIR . 'assets/images/product-gallery/' . $file ) ) {
			return '';
		}

		$alt   = (string) ( $f['alt'] ?? '' );
		$label = (string) ( $f['label'] ?? ( $reg['label'] ?? '' ) );
		$src   = GCALLS_CORE_URL . 'assets/images/product-gallery/' . $file;

		$out  = '<figure class="gcalls-shot">';
		$out .= '<img src="' . esc_url( $src ) . '" width="1600" height="900" alt="' . esc_attr( $alt ) . '" '
			. ( $eager ? 'fetchpriority="high" decoding="async">' : 'loading="lazy" decoding="async">' );

		// The label rides with the image, not in a caption further down the
		// page: on a phone the caption can be a screen away from the picture.
		if ( '' !== $label ) {
			$out .= '<figcaption class="gcalls-shot__label">' . esc_html( $label ) . '</figcaption>';
		}

		return $out . '</figure>';
	}

	/* --------------------------------------------- approved image gallery */

	/**
	 * Gcalls Plus visual gallery.
	 *
	 * These six frames came from the approved demo-image pack. They are bundled
	 * with the plugin rather than stored as attachment ids, so an update remains
	 * reproducible on every WordPress environment. The first image is eager and
	 * the remaining states are lazy; JavaScript only switches the visible frame.
	 */
	private static function mock_plus_gallery(): string {
		/*
		 * REFUSED IN FULL — this method no longer renders.
		 *
		 * All six frames it used to draw (overview, profile, history,
		 * analytics, agents, click) are marked REFUSED in data/media-frames.json:
		 * every one carries UNAPPROVED_DOMAIN_01 in a drawn browser bar, and
		 * between them fabricated contact names, phone numbers, per-agent
		 * performance tables and invented KPI tiles presented as measured
		 * results. GCALLS-039 removes the gallery rather than labelling it,
		 * because a label does not make an unapproved domain or an invented
		 * conversion rate acceptable.
		 *
		 * The Gcalls Plus hero is served by the drawn `customer_popup` mockup
		 * instead — call duration, timestamp and status only, which is the
		 * class of figure the checkpoint permits without a claim warning.
		 *
		 * The body is gone rather than commented out: there is no path that
		 * renders an unapproved frame, and self::frame() cannot be handed a
		 * filename to reintroduce one.
		 */
		return '';
	}


	/* --------------------------------------------------- 2. call timeline */

	/** CallTimelineSection — filterable call log with a playback bar. */
	private static function mock_call_timeline(): string {
		$tabs  = array( 'all' => 'Tất cả', 'in' => 'Đến', 'out' => 'Đi', 'missed' => 'Nhỡ' );
		$calls = array(
			array( 0, 'in', 'Đến', '7:18' ),
			array( 1, 'out', 'Đi', '3:42' ),
			array( 2, 'missed', 'Nhỡ', '—' ),
			array( 3, 'in', 'Đến', '2:05' ),
		);

		$out  = self::chrome( 'Lịch sử cuộc gọi' );
		$out .= '<div class="gcalls-mock__tabs" role="tablist" aria-label="Lọc cuộc gọi">';
		$first = true;
		foreach ( $tabs as $key => $label ) {
			$out  .= '<button type="button" role="tab" data-mock-tab="' . esc_attr( $key ) . '" aria-selected="' . ( $first ? 'true' : 'false' ) . '">' . esc_html( $label ) . '</button>';
			$first = false;
		}
		$out .= '</div><ul class="gcalls-mock__list">';

		foreach ( $calls as $call ) {
			$contact = self::CONTACTS[ $call[0] ];
			$out    .= '<li data-mock-type="' . esc_attr( $call[1] ) . '"><span class="gcalls-mock__avatar" aria-hidden="true">' . esc_html( mb_substr( $contact['name'], -1 ) ) . '</span>';
			$out    .= '<span class="gcalls-mock__who"><strong>' . esc_html( $contact['name'] ) . '</strong><small>' . esc_html( $contact['phone'] ) . '</small></span>';
			$out    .= '<span class="gcalls-mock__kind gcalls-mock__kind--' . esc_attr( $call[1] ) . '">' . esc_html( $call[2] ) . '</span>';
			$out    .= '<span class="gcalls-mock__dur">' . esc_html( $call[3] ) . '</span></li>';
		}

		$out .= '</ul>';
		$out .= '<div class="gcalls-mock__player"><button type="button" class="gcalls-mock__play" data-mock-play aria-pressed="false">';
		$out .= '<span class="screen-reader-text">Phát bản ghi minh họa</span><span aria-hidden="true">▶</span></button>';
		$out .= '<div class="gcalls-mock__track"><div class="gcalls-mock__fill" data-mock-progress style="width:44%"></div></div>';
		$out .= '<span class="gcalls-mock__time" data-mock-elapsed>0:44</span></div>';

		return $out . self::caption();
	}

	/* ----------------------------------------------------------- 3. CRM */

	/** CRMSection — contact list beside the selected contact's record. */
	private static function mock_crm(): string {
		$out  = self::chrome( 'Hồ sơ khách hàng' );
		$out .= '<div class="gcalls-mock__split"><ul class="gcalls-mock__side" role="tablist" aria-label="Danh bạ">';

		foreach ( self::CONTACTS as $index => $contact ) {
			$out .= '<li><button type="button" role="tab" data-mock-select="' . esc_attr( (string) $index ) . '" aria-selected="' . ( 0 === $index ? 'true' : 'false' ) . '">';
			$out .= '<strong>' . esc_html( $contact['name'] ) . '</strong><small>' . esc_html( $contact['org'] ) . '</small></button></li>';
		}

		$out .= '</ul><div class="gcalls-mock__pane">';

		foreach ( self::CONTACTS as $index => $contact ) {
			$out .= '<div class="gcalls-mock__record" data-mock-panel="' . esc_attr( (string) $index ) . '"' . ( 0 === $index ? '' : ' hidden' ) . '>';
			$out .= '<p class="gcalls-mock__record-name">' . esc_html( $contact['name'] ) . '</p>';
			$out .= '<dl><dt>Điện thoại</dt><dd>' . esc_html( $contact['phone'] ) . '</dd>';
			$out .= '<dt>Email</dt><dd>' . esc_html( 'lienhe' . ( $index + 1 ) . '@example.com' ) . '</dd>';
			$out .= '<dt>Công ty</dt><dd>' . esc_html( $contact['org'] ) . '</dd></dl>';
			$out .= '<p class="gcalls-mock__note"><strong>Ghi chú:</strong> Đã trao đổi nhu cầu, gửi tài liệu tuần này.</p>';
			$out .= '<ul class="gcalls-mock__events"><li><span>Cuộc gọi đến</span><small>7:18 phút · Ghi âm có sẵn</small></li>';
			$out .= '<li><span>Cuộc gọi đi</span><small>3:42 phút · Đã nghe máy</small></li></ul>';
			$out .= '</div>';
		}

		return $out . '</div></div>' . self::caption();
	}

	/* ------------------------------------------------------- 4. reporting */

	/**
	 * The reporting screen, stated without a single quantity.
	 *
	 * This replaces mock_analytics() everywhere the `analytics` id is used.
	 * What a reader needs from this panel is "the product has a reporting
	 * screen, and here is what it reports" — which is a claim about features,
	 * and true. What mock_analytics() added on top was "and here is how that
	 * reporting turned out": 114 calls, 73% answered, 3:25 average, over a
	 * weekly trend. None of those were measured anywhere, so all of them are
	 * gone rather than relabelled.
	 *
	 * Every value is an em dash. The period chips are <span>, not <button>:
	 * nothing in a still mockup responds to a click, and a control that looks
	 * live and is not reads as a broken page rather than as a picture.
	 */
	private static function mock_reporting(): string {
		$out = self::chrome( __( 'Báo cáo vận hành', 'gcalls-core' ) );

		$out .= '<div class="gcalls-mock__tabs gcalls-mock__tabs--static" aria-hidden="true">';

		foreach ( array( 'Ngày', 'Tuần', 'Tháng' ) as $index => $period ) {
			$out .= '<span' . ( 1 === $index ? ' class="is-on"' : '' ) . '>' . esc_html( $period ) . '</span>';
		}

		$out .= '</div>';

		/*
		 * Metric NAMES, never metric values. Naming what the product measures
		 * is a feature statement; filling it in would be a result.
		 */
		$metrics = array(
			__( 'Tổng cuộc gọi', 'gcalls-core' ),
			__( 'Tỷ lệ bắt máy', 'gcalls-core' ),
			__( 'Thời lượng trung bình', 'gcalls-core' ),
			__( 'Đánh giá sau cuộc gọi', 'gcalls-core' ),
		);

		$out .= '<ul class="gcalls-mock__metrics">';

		foreach ( $metrics as $metric ) {
			$out .= '<li class="gcalls-mock__metric"><span>' . esc_html( $metric ) . '</span>'
				. '<strong aria-label="' . esc_attr__( 'chưa có số liệu', 'gcalls-core' ) . '">—</strong></li>';
		}

		$out .= '</ul>';

		$out .= self::block(
			__( 'Trạng thái', 'gcalls-core' ),
			'<p class="gcalls-mock__empty">'
				. esc_html__( 'Chọn khoảng thời gian và bộ lọc để xem số liệu của bạn.', 'gcalls-core' )
				. '</p>'
		);

		return $out . self::caption( self::illustrative_label() );
	}

	/* ----------------------------------------------- 4b. analytics: REFUSED */

	/** AnalyticsSection — the range-switchable bar chart. */
	private static function mock_analytics(): string {
		$series = array(
			'day'   => array( 4, 9, 14, 11, 16, 7, 3 ),
			'week'  => array( 12, 18, 24, 17, 26, 11, 6 ),
			'month' => array( 48, 61, 74, 66, 82, 39, 21 ),
		);
		$labels = array( 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN' );

		$out  = self::chrome( 'Gcalls Analytics' );
		$out .= '<div class="gcalls-mock__tabs" role="tablist" aria-label="Khoảng thời gian">';
		foreach ( array( 'day' => 'Ngày', 'week' => 'Tuần', 'month' => 'Tháng' ) as $key => $label ) {
			$out .= '<button type="button" role="tab" data-mock-range="' . esc_attr( $key ) . '" aria-selected="' . ( 'week' === $key ? 'true' : 'false' ) . '">' . esc_html( $label ) . '</button>';
		}
		$out .= '</div>';

		$out .= '<div class="gcalls-mock__chart" data-mock-series="' . esc_attr( (string) wp_json_encode( $series ) ) . '">';
		$out .= '<div class="gcalls-mock__bars" role="img" aria-label="Biểu đồ minh họa số cuộc gọi theo ngày trong tuần">';
		foreach ( $series['week'] as $index => $value ) {
			$height = (int) round( ( $value / 26 ) * 100 );
			$out   .= '<span class="gcalls-mock__bar" data-mock-bar style="height:' . esc_attr( (string) $height ) . '%"><em>' . esc_html( $labels[ $index ] ) . '</em></span>';
		}
		$out .= '</div></div>';

		$out .= '<div class="gcalls-mock__kpis">';
		foreach ( array( array( 'Tổng cuộc gọi', '114' ), array( 'Tỷ lệ bắt máy', '73%' ), array( 'TB thời lượng', '3:25' ) ) as $kpi ) {
			$out .= '<div class="gcalls-mock__kpi"><span>' . esc_html( $kpi[0] ) . '</span><strong>' . esc_html( $kpi[1] ) . '</strong></div>';
		}
		$out .= '</div>';

		return $out . self::caption( __( 'Giao diện minh họa – dữ liệu demo, không phải kết quả đo được của một doanh nghiệp cụ thể', 'gcalls-core' ) );
	}

	/* ----------------------------------------------------------- 5. cloud */

	/** CloudSection — the SIP / IVR / routing configuration tabs. */
	private static function mock_cloud(): string {
		$panels = array(
			'sip'     => array( 'SIP Extensions', array( 'Tài khoản SIP cho từng nhân viên, đa thiết bị', 'Đăng nhập trên trình duyệt hoặc softphone', 'Trạng thái đăng ký hiển thị theo thời gian thực' ) ),
			'ivr'     => array( 'IVR', array( 'Cây menu tự động nhiều cấp, cấu hình linh hoạt', 'Lời chào và nhánh phím theo giờ làm việc', 'Chuyển tiếp khi không có phím bấm' ) ),
			'routing' => array( 'Call Routing', array( 'Điều hướng theo bộ phận, chi nhánh hoặc người phụ trách', 'Ring Group khi cần nhiều người cùng nhận', 'Call Forwarding khi không có người nhận máy' ) ),
		);

		$out  = self::chrome( 'Cấu hình tổng đài Cloud' );
		$out .= '<div class="gcalls-mock__tabs" role="tablist" aria-label="Cấu hình">';
		foreach ( $panels as $key => $panel ) {
			$out .= '<button type="button" role="tab" data-mock-select="' . esc_attr( $key ) . '" aria-selected="' . ( 'sip' === $key ? 'true' : 'false' ) . '">' . esc_html( $panel[0] ) . '</button>';
		}
		$out .= '</div>';

		foreach ( $panels as $key => $panel ) {
			$out .= '<div class="gcalls-mock__record" data-mock-panel="' . esc_attr( $key ) . '"' . ( 'sip' === $key ? '' : ' hidden' ) . '><ul class="gcalls-mock__ticks">';
			foreach ( $panel[1] as $line ) {
				$out .= '<li>' . esc_html( $line ) . '</li>';
			}
			$out .= '</ul></div>';
		}

		return $out . self::caption();
	}

	/* ----------------------------------------------- 6. integrations/API */

	/** IntegrationsSection — the endpoint list and the incoming-call popup. */
	private static function mock_integrations(): string {
		$endpoints = array(
			array( 'GET', '/calls', 'Lấy danh sách cuộc gọi' ),
			array( 'POST', '/calls', 'Khởi tạo cuộc gọi đi' ),
			array( 'GET', '/contacts/{id}', 'Chi tiết khách hàng' ),
			array( 'PATCH', '/contacts/{id}', 'Cập nhật thông tin KH' ),
			array( 'POST', '/webhooks', 'Đăng ký webhook event' ),
		);

		$out  = self::chrome( 'Open API' );
		$out .= '<ul class="gcalls-mock__api" role="tablist" aria-label="Endpoint">';
		foreach ( $endpoints as $index => $endpoint ) {
			$out .= '<li><button type="button" role="tab" data-mock-select="' . esc_attr( (string) $index ) . '" aria-selected="' . ( 0 === $index ? 'true' : 'false' ) . '">';
			$out .= '<span class="gcalls-mock__verb gcalls-mock__verb--' . esc_attr( strtolower( $endpoint[0] ) ) . '">' . esc_html( $endpoint[0] ) . '</span>';
			$out .= '<code>' . esc_html( $endpoint[1] ) . '</code><small>' . esc_html( $endpoint[2] ) . '</small></button></li>';
		}
		$out .= '</ul>';

		foreach ( $endpoints as $index => $endpoint ) {
			$out .= '<pre class="gcalls-mock__code" data-mock-panel="' . esc_attr( (string) $index ) . '"' . ( 0 === $index ? '' : ' hidden' ) . '>';
			$out .= esc_html( $endpoint[0] . ' https://api.example.com/v1' . $endpoint[1] ) . "\n";
			$out .= esc_html( 'Authorization: Bearer <token>' );
			$out .= '</pre>';
		}

		return $out . self::caption();
	}

	/* --------------------------------------------- 7. work from anywhere */

	/** WorkFromAnywhereSection — agent status board with a live call timer. */
	private static function mock_work_anywhere(): string {
		$filters = array( 'all' => 'Tất cả', 'available' => 'Sẵn sàng', 'in-call' => 'Đang gọi', 'away' => 'Vắng mặt', 'offline' => 'Ngoại tuyến' );

		$out  = self::chrome( 'Trạng thái đội ngũ' );
		$out .= '<div class="gcalls-mock__tabs" role="tablist" aria-label="Lọc trạng thái">';
		$first = true;
		foreach ( $filters as $key => $label ) {
			$out  .= '<button type="button" role="tab" data-mock-tab="' . esc_attr( $key ) . '" aria-selected="' . ( $first ? 'true' : 'false' ) . '">' . esc_html( $label ) . '</button>';
			$first = false;
		}
		$out .= '</div><ul class="gcalls-mock__list">';

		foreach ( self::AGENTS as $agent ) {
			$out .= '<li data-mock-type="' . esc_attr( $agent['state'] ) . '">';
			$out .= '<span class="gcalls-mock__status gcalls-mock__status--' . esc_attr( $agent['state'] ) . '" aria-hidden="true"></span>';
			$out .= '<span class="gcalls-mock__who"><strong>' . esc_html( $agent['name'] ) . '</strong><small>' . esc_html( $agent['label'] ) . '</small></span>';
			$out .= 'in-call' === $agent['state']
				? '<span class="gcalls-mock__dur" data-mock-timer>00:42</span>'
				: '<span class="gcalls-mock__dur">—</span>';
			$out .= '</li>';
		}

		return $out . '</ul>' . self::caption();
	}

	/* ------------------------------------------------- product demo visuals */

	/*
	 * Eleven surfaces, ported one-for-one from the React product pages.
	 *
	 * WHY ONE PER SECTION AND NOT ONE REUSED
	 * The port used to answer four CX sections with two panels and a pair of
	 * generic CRM/analytics mockups, which meant "báo cáo vận hành" and
	 * "hồ sơ khách hàng" showed the same picture with a different heading. A
	 * visual that does not depict its own section is worse than none: it tells
	 * the reader the screenshots are decorative. Each section now gets the
	 * component the reference gives it.
	 *
	 * IDENTIFIERS
	 * The reference already anonymises these — masked ids (KH #4821, #A-1042,
	 * LH-2481) and role labels (Agent 02), never a person or a company. That is
	 * carried across unchanged; nothing here needed inventing or scrubbing.
	 *
	 * THE NUMBERS
	 * Every figure is demo data under the caption each mockup prints. None is
	 * framed as a result: there is no percentage improvement, no saving and no
	 * outcome attributed to Gcalls anywhere in this block.
	 */

	/** The five verified Gcalls CX channels. Nothing outside this list. */
	private const CHANNELS = array(
		'voice'    => 'Voice',
		'zalo'     => 'Zalo',
		'facebook' => 'Facebook',
		'sms'      => 'SMS',
		'email'    => 'Email',
	);

	/** One channel pill. Colour comes from the class, never from markup. */
	private static function chan( string $key ): string {
		$label = self::CHANNELS[ $key ] ?? $key;

		return '<span class="gcalls-chan gcalls-chan--' . esc_attr( $key ) . '">' . esc_html( $label ) . '</span>';
	}

	/** A status pill: brand by default, amber when it needs attention. */
	private static function state( string $label, bool $warn = false ): string {
		return '<span class="gcalls-state' . ( $warn ? ' gcalls-state--warn' : '' ) . '">' . esc_html( $label ) . '</span>';
	}

	/**
	 * The placeholder every unsourced figure renders as.
	 *
	 * An em dash, not "0" and not "N/A": zero is itself a measurement, and
	 * "N/A" reads as an error state. A dash reads as "this is where a number
	 * goes", which is exactly what a mockup is for.
	 */
	private const FIGURE = '—';

	/**
	 * A row of figure tiles — the METRICS a screen reports, never their values.
	 *
	 * GCALLS-041. This used to take label/value pairs, and the values were
	 * invented: 312 conversations, 47 open tickets, 480 contacts, an average QA
	 * score of 81. GCALLS-039 refused mock_analytics() for exactly that, so the
	 * same rule is applied here rather than kept for one drawing.
	 *
	 * THE SIGNATURE IS THE ENFORCEMENT. It accepts labels only, so a caller
	 * cannot supply a number at all — the way frame() refuses to accept a
	 * filename. Relabelling would have left the next person free to type a
	 * figure back in; removing the parameter does not.
	 *
	 * The label rides with the component, not with the caller: on a phone a
	 * bottom caption can be a screen away from the tiles it qualifies.
	 *
	 * @param array<int, string> $labels Metric names.
	 * @return string
	 */
	private static function tiles( array $labels ): string {
		$out  = '<div class="gcalls-tiles-wrap">';
		$out .= '<p class="gcalls-tiles__label">' . esc_html( self::illustrative_label() ) . '</p>';
		$out .= '<ul class="gcalls-tiles">';

		foreach ( $labels as $label ) {
			$out .= '<li class="gcalls-tile">'
				. '<strong aria-label="' . esc_attr__( 'chưa có số liệu', 'gcalls-core' ) . '">' . self::FIGURE . '</strong>'
				. '<span>' . esc_html( $label ) . '</span></li>';
		}

		return $out . '</ul></div>';
	}

	/** A titled sub-panel. */
	private static function block( string $title, string $body ): string {
		return '<div class="gcalls-block"><p class="gcalls-block__t">' . esc_html( $title ) . '</p>' . $body . '</div>';
	}

	/* ---- Gcalls CX ---------------------------------------------------- */

	/** OmnichannelInboxMockup — conversations from the connected channels. */
	private static function mock_cx_inbox(): string {
		$rows = array(
			array( 'KH #4821', 'zalo', 'Đơn của mình khi nào giao?', 'Chờ xử lý', true ),
			array( 'KH #4817', 'voice', 'Cuộc gọi đến · 2:14', 'Đang xử lý', false ),
			array( 'KH #4813', 'facebook', 'Shop còn size M không ạ?', 'Đang xử lý', false ),
			array( 'KH #4809', 'email', 'Yêu cầu xuất hóa đơn', 'Đã xong', false ),
			array( 'KH #4804', 'sms', 'Xác nhận lịch hẹn', 'Đã xong', false ),
		);

		$out  = self::chrome( 'Omnichannel Inbox' );
		$out .= '<div class="gcalls-chanbar"><span class="gcalls-chanbar__all">Tất cả</span>';
		foreach ( array_keys( self::CHANNELS ) as $key ) {
			$out .= self::chan( $key );
		}
		$out .= '</div>';

		$out .= '<ul class="gcalls-rows">';
		foreach ( $rows as $row ) {
			$out .= '<li class="gcalls-row"><span class="gcalls-row__main">';
			$out .= '<span class="gcalls-row__head"><b>' . esc_html( $row[0] ) . '</b>' . self::chan( $row[1] ) . '</span>';
			$out .= '<small>' . esc_html( $row[2] ) . '</small></span>';
			$out .= self::state( $row[3], $row[4] ) . '</li>';
		}

		return $out . '</ul>' . self::caption();
	}

	/** TicketPanelMockup — status, assignee and the handling history. */
	private static function mock_cx_ticket(): string {
		$history = array(
			array( '09:12', 'Tiếp nhận từ Zalo OA' ),
			array( '09:20', 'Phân công cho Agent 02' ),
			array( '10:05', 'Đã phản hồi khách hàng' ),
		);

		$out  = self::chrome( 'Ticket #T-2043' );
		$out .= '<div class="gcalls-pad">';
		$out .= '<div class="gcalls-row__head">' . self::state( 'Đang xử lý', true ) . self::chan( 'zalo' );
		$out .= '<span class="gcalls-row__by">Phụ trách: Agent 02</span></div>';
		$out .= '<p class="gcalls-lead"><b>Yêu cầu kiểm tra tình trạng đơn hàng</b></p>';
		$out .= '<p class="gcalls-sub">Khách hàng liên hệ qua Zalo OA và cần cập nhật thời gian giao dự kiến.</p>';

		$out .= '<ul class="gcalls-hist">';
		foreach ( $history as $item ) {
			$out .= '<li><span class="gcalls-hist__at">' . esc_html( $item[0] ) . '</span>'
				. '<span>' . esc_html( $item[1] ) . '</span></li>';
		}

		return $out . '</ul></div>' . self::caption();
	}

	/** CustomerContextMockup — one customer, every channel they used. */
	private static function mock_cx_context(): string {
		$recent = array(
			array( 'zalo', 'Hỏi tình trạng đơn hàng', 'Hôm nay' ),
			array( 'voice', 'Cuộc gọi đến · 2:14', 'Hôm qua' ),
			array( 'email', 'Yêu cầu xuất hóa đơn', '3 ngày trước' ),
		);

		$out  = self::chrome( 'Customer Context' );
		$out .= '<div class="gcalls-pad">';
		$out .= '<div class="gcalls-who"><span class="gcalls-mock__avatar">KH</span>';
		$out .= '<span class="gcalls-mock__who"><strong>KH #4821</strong>'
			. '<small>Khách hàng · 3 kênh đã tương tác</small></span></div>';

		$out .= '<div class="gcalls-chanrow">' . self::chan( 'zalo' ) . self::chan( 'voice' ) . self::chan( 'email' ) . '</div>';

		$out .= '<p class="gcalls-block__t">Tương tác gần đây</p><ul class="gcalls-recent">';
		foreach ( $recent as $item ) {
			$out .= '<li>' . self::chan( $item[0] ) . '<span>' . esc_html( $item[1] ) . '</span>'
				. '<i>' . esc_html( $item[2] ) . '</i></li>';
		}
		$out .= '</ul>';

		$out .= '<div class="gcalls-note"><p class="gcalls-block__t">Ticket liên quan</p>'
			. '<p>#T-2043 · Đang xử lý · Agent 02</p></div>';

		return $out . '</div>' . self::caption();
	}

	/** CxReportingMockup — workload, ticket status, channel distribution. */
	private static function mock_cx_report(): string {
		$statuses = array(
			array( 'Chờ xử lý', 12, 'warn' ),
			array( 'Đang xử lý', 21, 'brand' ),
			array( 'Đã xong', 14, 'ok' ),
		);
		$dist     = array(
			array( 'voice', 34 ),
			array( 'zalo', 28 ),
			array( 'facebook', 19 ),
			array( 'email', 12 ),
			array( 'sms', 7 ),
		);

		$max = 0;
		foreach ( $statuses as $status ) {
			$max = max( $max, $status[1] );
		}

		$out  = self::chrome( 'Báo cáo vận hành' );
		$out .= '<div class="gcalls-pad">';
		$out .= self::tiles(
			array( 'Hội thoại hôm nay', 'Ticket đang mở' )
		);

		$bars = '<ul class="gcalls-meters">';
		foreach ( $statuses as $status ) {
			$width = 0 === $max ? 0 : (int) round( ( $status[1] / $max ) * 100 );
			$bars .= '<li><span class="gcalls-meters__l">' . esc_html( $status[0] ) . '</span>';
			$bars .= '<span class="gcalls-meters__track"><span class="gcalls-meters__fill gcalls-meters__fill--'
				. esc_attr( $status[2] ) . '" style="width:' . esc_attr( (string) $width ) . '%"></span></span>';
			$bars .= '<b>' . self::FIGURE . '</b></li>';
		}
		$bars .= '</ul>';
		$out  .= self::block( 'Trạng thái ticket', $bars );

		$rows = '<ul class="gcalls-meters gcalls-meters--chan">';
		foreach ( $dist as $item ) {
			$rows .= '<li>' . self::chan( $item[0] );
			$rows .= '<span class="gcalls-meters__track"><span class="gcalls-meters__fill" style="width:'
				. esc_attr( (string) $item[1] ) . '%"></span></span>';
			$rows .= '<b>' . self::FIGURE . '</b></li>';
		}
		$rows .= '</ul>';
		$out  .= self::block( 'Phân bổ theo kênh', $rows );

		return $out . '</div>' . self::caption();
	}

	/* ---- Voicebot AI --------------------------------------------------- */

	/** VoicebotCampaignMockup — the campaign console. */
	private static function mock_voicebot_builder(): string {
		$outcomes = array(
			array( 'Xác nhận lịch hẹn', 46, 'brand' ),
			array( 'Đề nghị gọi lại', 27, 'brand' ),
			array( 'Cần nhân viên hỗ trợ', 15, 'warn' ),
			array( 'Không kết nối', 12, 'muted' ),
		);
		$history  = array(
			array( 'LH-2481', '09:12', 'Đã xác nhận' ),
			array( 'LH-2479', '09:08', 'Chuyển nhân viên' ),
			array( 'LH-2476', '09:03', 'Hẹn gọi lại' ),
		);

		$out  = self::chrome( 'Voicebot · Chiến dịch nhắc lịch hẹn' );
		$out .= '<div class="gcalls-chanbar"><span class="gcalls-mock__pulse" aria-hidden="true"></span>';
		$out .= '<span class="gcalls-row__by">Chiến dịch đang chạy</span>';
		$out .= '<span class="gcalls-state">Minh họa</span></div>';

		$out .= '<div class="gcalls-pad">';
		$out .= self::tiles(
			array( 'Trong danh sách', 'Đã gọi', 'Đã kết nối', 'Cần nhân viên' )
		);

		$bars = '<ul class="gcalls-outcomes">';
		foreach ( $outcomes as $outcome ) {
			$bars .= '<li><span class="gcalls-outcomes__head"><span>' . esc_html( $outcome[0] ) . '</span>'
				. '<b>' . self::FIGURE . '</b></span>';
			$bars .= '<span class="gcalls-meters__track"><span class="gcalls-meters__fill gcalls-meters__fill--'
				. esc_attr( $outcome[2] ) . '" style="width:' . esc_attr( (string) $outcome[1] ) . '%"></span></span></li>';
		}
		$bars .= '</ul>';
		$out  .= self::block( 'Kết quả phản hồi', $bars );

		$rows = '<ul class="gcalls-rows gcalls-rows--tight">';
		foreach ( $history as $item ) {
			$rows .= '<li class="gcalls-row"><b class="gcalls-row__id">' . esc_html( $item[0] ) . '</b>';
			$rows .= '<span class="gcalls-hist__at">' . esc_html( $item[1] ) . '</span>';
			$rows .= '<span class="gcalls-row__end">' . esc_html( $item[2] ) . '</span></li>';
		}
		$rows .= '</ul>';
		$out  .= self::block( 'Lịch sử tương tác', $rows );

		return $out . '</div>' . self::caption();
	}

	/** VoicebotHandoffMockup — the calls the bot routed to a person. */
	private static function mock_voicebot_handoff(): string {
		$rows = array(
			array( 'LH-2479', 'Khách hỏi ngoài kịch bản', 'Tư vấn' ),
			array( 'LH-2465', 'Đề nghị thương lượng điều khoản', 'Tư vấn' ),
			array( 'LH-2452', 'Phản hồi cần xử lý riêng', 'CSKH' ),
			array( 'LH-2440', 'Yêu cầu gặp nhân viên', 'CSKH' ),
		);

		$out  = self::chrome( 'Hàng đợi chuyển nhân viên' );
		$out .= '<ul class="gcalls-rows">';
		foreach ( $rows as $row ) {
			$out .= '<li class="gcalls-row"><b class="gcalls-row__id">' . esc_html( $row[0] ) . '</b>';
			$out .= '<span class="gcalls-row__main"><small>' . esc_html( $row[1] ) . '</small></span>';
			$out .= self::state( $row[2] ) . '</li>';
		}

		return $out . '</ul>' . self::caption();
	}

	/* ---- QC Bot AI ----------------------------------------------------- */

	/** TranscriptMockup — speech-to-text output with one flagged keyword. */
	private static function mock_qc_transcript(): string {
		$turns = array(
			array( 'Nhân viên 01', '00:04', 'Dạ em nghe, em có thể hỗ trợ mình thông tin gì ạ?', '' ),
			array( 'Khách hàng A', '00:11', 'Tôi gọi lần thứ hai rồi mà vẫn chưa được xử lý.', 'lặp lại liên hệ' ),
			array( 'Nhân viên 01', '00:19', 'Em xin lỗi vì sự bất tiện này, em kiểm tra ngay giúp mình ạ.', '' ),
			array( 'Khách hàng A', '00:31', 'Vậy bao lâu thì tôi nhận được phản hồi?', '' ),
		);

		$out  = self::chrome( 'Transcript · Cuộc gọi #A-1042' );
		$out .= '<div class="gcalls-chanbar"><span class="gcalls-row__by">Tìm trong transcript…</span>';
		$out .= '<span class="gcalls-state">Demo</span></div>';

		$out .= '<ul class="gcalls-turns">';
		foreach ( $turns as $turn ) {
			$out .= '<li><span class="gcalls-hist__at">' . esc_html( $turn[1] ) . '</span><span>';
			$out .= '<b class="gcalls-turns__who">' . esc_html( $turn[0] ) . '</b>';
			$out .= '<span class="gcalls-turns__text">' . esc_html( $turn[2] ) . '</span>';
			if ( '' !== $turn[3] ) {
				$out .= '<span class="gcalls-state gcalls-state--warn">Từ khóa: ' . esc_html( $turn[3] ) . '</span>';
			}
			$out .= '</span></li>';
		}

		return $out . '</ul>' . self::caption();
	}

	/** ScoreCardMockup — criteria, weights and a score awaiting a human. */
	private static function mock_qc_scorecard(): string {
		$criteria = array(
			array( 'Chào hỏi & xác minh', '20%', true ),
			array( 'Tuân thủ kịch bản', '30%', true ),
			array( 'Xử lý phản hồi', '30%', false ),
			array( 'Kết thúc cuộc gọi', '20%', true ),
		);

		$out  = self::chrome( 'QA Scoring' );
		$out .= '<div class="gcalls-pad">';
		// "Điểm đề xuất … chờ QA xác nhận" is the reference's framing and it
		// matters: the product proposes, a person decides. A bare score would
		// claim the machine grades the call.
		$out .= '<div class="gcalls-score"><span><b>Điểm đề xuất</b><small>Chờ QA xác nhận</small></span>';
		$out .= '<em aria-label="' . esc_attr__( 'chưa có số liệu', 'gcalls-core' ) . '">' . self::FIGURE . '</em></div>';

		$out .= '<ul class="gcalls-crit">';
		foreach ( $criteria as $item ) {
			$out .= '<li><span class="gcalls-crit__i gcalls-crit__i--' . ( $item[2] ? 'ok' : 'no' ) . '" aria-hidden="true">'
				. ( $item[2] ? '✓' : '!' ) . '</span>';
			$out .= '<span class="gcalls-crit__l">' . esc_html( $item[0] ) . '</span>';
			/*
			 * A CRITERION WEIGHT IS CONFIGURATION, NOT A RESULT.
			 *
			 * 20/30/30/20 describes how this scorecard is defined and sums to
			 * 100; it says nothing about how any call went. The score above it
			 * is the opposite and is now a dash. Marking the weight with its
			 * own class keeps that distinction machine-checkable, so the
			 * "no figures" sweep can exempt exactly this and nothing else.
			 */
			$out .= '<b class="gcalls-crit__w">' . esc_html( $item[1] ) . '</b></li>';
		}

		return $out . '</ul></div>' . self::caption();
	}

	/** SignalsMockup — the flagged-call queue. */
	private static function mock_qc_signals(): string {
		$rows = array(
			array( '#A-1042', 'Lặp lại liên hệ', 'Tiêu cực', true ),
			array( '#A-1039', 'Yêu cầu hoàn tiền', 'Tiêu cực', true ),
			array( '#A-1035', 'Hỏi chính sách', 'Trung tính', false ),
			array( '#A-1028', 'Xác nhận đơn', 'Tích cực', false ),
		);

		$out  = self::chrome( 'Conversation Signals' );
		$out .= '<div class="gcalls-chanbar"><span class="gcalls-row__by">Cuộc gọi cần xem lại</span>';
		$out .= '<span class="gcalls-row__end">Dữ liệu mẫu</span></div>';

		$out .= '<ul class="gcalls-rows">';
		foreach ( $rows as $row ) {
			$out .= '<li class="gcalls-row"><b class="gcalls-row__id">' . esc_html( $row[0] ) . '</b>';
			$out .= '<span class="gcalls-row__main"><small>' . esc_html( $row[1] ) . '</small></span>';
			$out .= self::state( $row[2], $row[3] ) . '</li>';
		}

		return $out . '</ul>' . self::caption();
	}

	/** QualityDashboardMockup — the aggregate view. */
	private static function mock_qc_dashboard(): string {
		$bars = array(
			array( 'T2', 62 ),
			array( 'T3', 74 ),
			array( 'T4', 58 ),
			array( 'T5', 88 ),
			array( 'T6', 79 ),
			array( 'T7', 41 ),
		);

		$out  = self::chrome( 'Quality Dashboard' );
		$out .= '<div class="gcalls-pad">';
		$out .= self::tiles(
			array( 'Cuộc gọi đã phân tích', 'Cần xem lại', 'Điểm QA trung bình', 'Phiên review tuần này' )
		);

		$trend = '<div class="gcalls-trend" aria-hidden="true">';
		foreach ( $bars as $bar ) {
			$trend .= '<span class="gcalls-trend__col"><span class="gcalls-trend__bar" style="height:'
				. esc_attr( (string) $bar[1] ) . '%"></span><small>' . esc_html( $bar[0] ) . '</small></span>';
		}
		$trend .= '</div>';
		$out   .= self::block( 'Xu hướng điểm QA', $trend );

		return $out . '</div>' . self::caption();
	}

	/** ReviewWorkspaceMockup — transcript beside the criteria. */
	private static function mock_qc_review(): string {
		$turns = array(
			array( 'Nhân viên 01', 'Dạ em nghe, em hỗ trợ mình ạ.' ),
			array( 'Khách hàng A', 'Tôi gọi lần thứ hai rồi.' ),
			array( 'Nhân viên 01', 'Em xin lỗi, em kiểm tra ngay ạ.' ),
		);
		$crit  = array(
			array( 'Chào hỏi', true ),
			array( 'Kịch bản', true ),
			array( 'Xử lý phản hồi', false ),
		);

		$out  = self::chrome( 'Conversation Review' );
		$out .= '<div class="gcalls-mock__split">';

		$out .= '<div class="gcalls-mock__pane"><p class="gcalls-block__t">Transcript</p><ul class="gcalls-turns">';
		foreach ( $turns as $turn ) {
			$out .= '<li><span><b class="gcalls-turns__who">' . esc_html( $turn[0] ) . '</b>'
				. '<span class="gcalls-turns__text">' . esc_html( $turn[1] ) . '</span></span></li>';
		}
		$out .= '</ul></div>';

		$out .= '<div class="gcalls-mock__pane"><p class="gcalls-block__t">Tiêu chí QA</p><ul class="gcalls-crit">';
		foreach ( $crit as $item ) {
			$out .= '<li><span class="gcalls-crit__i gcalls-crit__i--' . ( $item[1] ? 'ok' : 'no' ) . '" aria-hidden="true">'
				. ( $item[1] ? '✓' : '!' ) . '</span><span class="gcalls-crit__l">' . esc_html( $item[0] ) . '</span></li>';
		}
		$out .= '</ul><div class="gcalls-note"><p class="gcalls-block__t">Điểm đề xuất</p>'
			. '<p class="gcalls-note__big">78</p><small>Chờ QA xác nhận</small></div></div>';

		return $out . '</div>' . self::caption();
	}

	/* ------------------------------------- 9. customer popup / 10. widget */

	/**
	 * CustomerPopupSection — the screen pop when a call arrives.
	 *
	 * Ported from IntegrationsSection.tsx's CustomerPopupMockup, which is an
	 * interactive component: it opens ringing, and answering it switches the
	 * bar to "Đã kết nối". The port previously showed a static screenshot
	 * instead, which meant the one section whose whole argument is "this
	 * happens the moment a call arrives" could not demonstrate the moment.
	 *
	 * The reference's invented personal name and company are NOT carried over;
	 * this uses the anonymous demo contacts like every other mockup here. See
	 * the file header for why that rule exists.
	 */
	private static function mock_customer_popup(): string {
		$history = array(
			array( 'Gọi đi · 3:42', 'Hôm nay 09:14' ),
			array( 'Ghi chú: cần gửi báo giá', 'Hôm nay 09:35' ),
		);

		$out  = '<div class="gcalls-pop" data-mock-pop>';
		$out .= '<div class="gcalls-pop__bar">';
		$out .= '<span class="gcalls-pop__ring" aria-hidden="true"></span>';
		$out .= '<span class="gcalls-pop__state"><strong data-mock-pop-state>Cuộc gọi đến…</strong>';
		$out .= '<small>' . esc_html( self::CONTACTS[0]['phone'] ) . ' · Hotline demo</small></span>';
		$out .= '<span class="gcalls-pop__acts">';
		$out .= '<button type="button" class="gcalls-pop__btn gcalls-pop__btn--yes" data-mock-pop-answer>'
			. '<span class="screen-reader-text">' . esc_html__( 'Bắt máy', 'gcalls-core' ) . '</span><span aria-hidden="true">✆</span></button>';
		$out .= '<button type="button" class="gcalls-pop__btn gcalls-pop__btn--no" data-mock-pop-reject>'
			. '<span class="screen-reader-text">' . esc_html__( 'Từ chối cuộc gọi', 'gcalls-core' ) . '</span><span aria-hidden="true">✕</span></button>';
		$out .= '</span></div>';

		$out .= '<div class="gcalls-pop__body">';
		$out .= '<div class="gcalls-pop__who"><span class="gcalls-mock__avatar">A</span>';
		$out .= '<span class="gcalls-mock__who"><strong>' . esc_html( self::CONTACTS[0]['name'] ) . '</strong>';
		$out .= '<small>' . esc_html( self::CONTACTS[0]['org'] ) . '</small></span>';
		$out .= '<span class="gcalls-mock__badge">' . esc_html( self::CONTACTS[0]['tag'] ) . '</span></div>';

		$out .= '<div class="gcalls-pop__hist"><span class="gcalls-pop__histhead">Lịch sử gần nhất</span>';
		foreach ( $history as $item ) {
			$out .= '<span class="gcalls-pop__row"><em>' . esc_html( $item[0] ) . '</em><i>' . esc_html( $item[1] ) . '</i></span>';
		}
		$out .= '</div>';

		$out .= '<div class="gcalls-pop__quick">';
		foreach ( array( 'Ghi chú', 'Gắn tag', 'Xem hồ sơ' ) as $action ) {
			$out .= '<button type="button">' . esc_html( $action ) . '</button>';
		}
		$out .= '</div></div></div>';

		return $out . self::caption();
	}

	/**
	 * CallWidgetSection — the call button a visitor opens on a website.
	 *
	 * Ported from WidgetMockup, which opens and closes and takes a number.
	 * The port showed a configuration screenshot: correct subject, wrong
	 * argument — the section sells what the VISITOR sees, not what the admin
	 * configures.
	 */
	private static function mock_widget(): string {
		$out  = '<div class="gcalls-widget" data-mock-widget>';
		$out .= '<div class="gcalls-widget__page" aria-hidden="true">';
		$out .= '<span class="gcalls-widget__bar"></span><span class="gcalls-widget__line"></span>';
		$out .= '<span class="gcalls-widget__line gcalls-widget__line--short"></span>';
		$out .= '</div>';

		$out .= '<div class="gcalls-widget__panel" data-mock-widget-panel hidden>';
		$out .= '<div class="gcalls-widget__head"><strong>' . esc_html__( 'Gọi lại cho tôi', 'gcalls-core' ) . '</strong>';
		$out .= '<small>' . esc_html__( 'Để lại số điện thoại, đội ngũ sẽ liên hệ lại.', 'gcalls-core' ) . '</small></div>';
		// A demo field: it is deliberately not a form and posts nowhere, so no
		// visitor can believe they have submitted a number to anyone.
		$out .= '<div class="gcalls-widget__field" aria-hidden="true">090 *** **12</div>';
		$out .= '<span class="gcalls-widget__send">' . esc_html__( 'Yêu cầu gọi lại', 'gcalls-core' ) . '</span>';
		$out .= '</div>';

		$out .= '<button type="button" class="gcalls-widget__fab" data-mock-widget-toggle aria-expanded="false">';
		$out .= '<span aria-hidden="true">✆</span><span class="screen-reader-text">'
			. esc_html__( 'Mở khung gọi lại minh họa', 'gcalls-core' ) . '</span></button>';
		$out .= '</div>';

		return $out . self::caption();
	}

	/* ------------------------------------------------- product hero shots */

	/**
	 * One demo image, filling its own reserved box.
	 *
	 * These three are heroes, so the image is eager and high priority: it is
	 * the largest paint on the page and waiting for it is the page waiting.
	 * Width and height are attributes, not CSS alone, so the box is reserved
	 * before the bytes arrive and nothing below it moves.
	 *
	 * @param string $id Registry id in data/media-frames.json.
	 * @param string $alt  Alt text — describes the interface, not the file.
	 */
	private static function showcase( string $id ): string {
		/*
		 * Takes a REGISTRY ID, never a filename. The previous signature took
		 * ( $file, $alt ) and built a URL directly, which is exactly how six
		 * refused images reached the page without any policy check.
		 */
		return self::frame( $id, true );
	}


	/** Gcalls CX hero — the unified inbox, as a full application frame. */
	private static function mock_cx_showcase(): string {
		return self::showcase( 'cx-omnichannel' );
	}

	/** Voicebot AI hero — the script builder canvas. */
	private static function mock_voicebot_showcase(): string {
		return self::showcase( 'voicebot-flow' );
	}

	/** QC Bot AI hero — transcript beside the scorecard. */
	private static function mock_qc_showcase(): string {
		return self::showcase( 'qc-scoring' );
	}
}
